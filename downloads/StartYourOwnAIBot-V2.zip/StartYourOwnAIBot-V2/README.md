# Start Your Own AI Bot — V2

## Open the game (recommended)
1. Extract the ZIP if you downloaded it.
2. In Roblox Studio, choose **File → Open from File** and select `StartYourOwnAIBot-V2.rbxlx`.
3. Press **Play**. No plugins, asset imports, HTTP access, API keys, or npm are needed.
4. Use the **Next** and **Skip story** buttons during the opening.
5. Follow the mint floor marker/path into the warehouse. Walk to the workbench and press **E** (or tap its interaction prompt).
6. Buy the course with $10 of the $25 starting in-game cash. Invest $10 to train your first bot.
7. Income arrives automatically every four seconds. Leave the laptop and inspect upgrade terminals to buy physical improvements.

The opening can be skipped entirely. Skipping still starts the warehouse tutorial with the correct cash and camera state.

## Replace the first prototype in an existing place
Open `Install-AIBot-V2.luau` in a text editor. Copy its complete contents into Studio's **Command Bar** in Edit mode and press Enter. The installer replaces only the named AI Bot prototype scripts and map objects. It does not clear your place or modify other scripts. A pre-existing Baseplate may overlap the new ground; remove your old Baseplate manually if necessary. Using the included place avoids old-script and map conflicts.

## What changed
- Procedural bedroom: oak floor, rug, made bed, pillows, desk, chair, books, monitor, keyboard, mouse, coffee, curtains, lamp, poster, and plant.
- Warehouse: brick and concrete walls, steel trusses, industrial windows, pendant lights, workbench, pegboard/tools, crates, rugs, site signage, trees, planters, road, and a taxi with windows, wheels, lamps and door details.
- Styled procedural mom character with face, hair/bun, clothing, and hands. She is an original primitive-built character, not a purchased mesh or production animation rig.
- Higher, predictable camera shots; short dialogue beats; Next/Skip controls; reliable return to the third-person camera.
- Compact objective/cash HUD and a world-space path. No large tutorial panel covering the character.
- Dedicated scrollable laptop UI with training progress, cash, earnings and capacity. Space or the close button exits laptop mode. Mobile interaction uses on-screen buttons and ProximityPrompts.
- Server-validated money, proximity, training, purchases and passive income.
- Separate plots for concurrent players, with cleanup when they leave.

## Gameplay
Cash is fictional. Course: $10. Training starts at $10, increasing $8 per existing level. Base capacity: 3 levels. Income: $3 per level every 4 seconds.

Dual displays: $75, capacity +4 and earnings +25%.
Server rack: $200, capacity +6 and earnings x2.
Studio lounge: $125, earnings +50%.

## Honest scope and validation
This is a substantially rebuilt procedural prototype, not a finished published game. The bot is simulated; it does not call an AI provider. No progress persistence, production character animation, voice acting, music, monetization or moderation systems are included. All money and upgrades reset on rejoining.

The build validates XML structure, references, scene anchors, upgrade groups, script/source packaging and progression reachability locally. Roblox Studio is unavailable in the build environment: visual appearance, engine API compatibility, camera collisions, touch layout, multiplayer replication and actual gameplay still require Studio Play testing. Do not treat static validation as a Roblox runtime test.

Test checklist: watch and skip the opening; verify camera/control restoration; enter warehouse; place laptop; buy course; train; receive income; exit laptop; buy each upgrade; test full-capacity and insufficient-cash messages; reset character; test two players in Studio's server test mode.

Edit `Server.luau` / `Client.luau` in Studio after opening the place. `build.py` in the source workspace generates both the XML place and installer from the same scene specification. The original chatbot files are unrelated and were left intact.
